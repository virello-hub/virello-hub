"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import type { User } from "@supabase/supabase-js";

import Header from "../components/Header";
import { supabase } from "@/lib/supabase/client";

type RewardsData = {
  email: string;
  first_name: string | null;
  last_name: string | null;
  total_points: number;
  available_points: number;
  lifetime_spent: number;
  orders_count: number;
  gifts_received: number;
  level: string;
};

type LevelInfo = {
  name: string;
  icon: string;
  minimum: number;
  nextName: string | null;
  nextMinimum: number | null;
};

function formatPrice(value: number) {
  return `${value.toFixed(2).replace(".", ",")} lei`;
}

function getLevelInfo(points: number): LevelInfo {
  if (points >= 5000) {
    return {
      name: "Diamond",
      icon: "💎",
      minimum: 5000,
      nextName: null,
      nextMinimum: null,
    };
  }

  if (points >= 1500) {
    return {
      name: "Gold",
      icon: "🥇",
      minimum: 1500,
      nextName: "Diamond",
      nextMinimum: 5000,
    };
  }

  if (points >= 500) {
    return {
      name: "Silver",
      icon: "🥈",
      minimum: 500,
      nextName: "Gold",
      nextMinimum: 1500,
    };
  }

  return {
    name: "Bronze",
    icon: "🥉",
    minimum: 0,
    nextName: "Silver",
    nextMinimum: 500,
  };
}

function getProgress(
  points: number,
  currentMinimum: number,
  nextMinimum: number | null
) {
  if (!nextMinimum) {
    return 100;
  }

  const range = nextMinimum - currentMinimum;
  const progressInsideLevel = points - currentMinimum;

  return Math.min(
    Math.max((progressInsideLevel / range) * 100, 0),
    100
  );
}

export default function ContPage() {
  const router = useRouter();

  const [user, setUser] = useState<User | null>(null);
  const [rewards, setRewards] = useState<RewardsData | null>(null);

  const [loaded, setLoaded] = useState(false);
  const [signingOut, setSigningOut] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    let active = true;

    async function loadAccount() {
      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!active) {
        return;
      }

      if (!session?.user) {
        router.replace("/Login");
        return;
      }

      setUser(session.user);

      const email = session.user.email?.toLowerCase();

      if (!email) {
        setErrorMessage(
          "Contul nu are o adresă de email disponibilă."
        );
        setLoaded(true);
        return;
      }

      const { data, error } = await supabase
        .from("customer_rewards")
        .select(
          "email, first_name, last_name, total_points, available_points, lifetime_spent, orders_count, gifts_received, level"
        )
        .eq("email", email)
        .maybeSingle();

      if (!active) {
        return;
      }

      if (error) {
        console.error("Datele contului nu au putut fi încărcate:", error);
        setErrorMessage(
          "Datele VIRELLO Rewards nu au putut fi încărcate."
        );
      } else if (data) {
        setRewards({
          email: data.email,
          first_name: data.first_name,
          last_name: data.last_name,
          total_points: Number(data.total_points) || 0,
          available_points: Number(data.available_points) || 0,
          lifetime_spent: Number(data.lifetime_spent) || 0,
          orders_count: Number(data.orders_count) || 0,
          gifts_received: Number(data.gifts_received) || 0,
          level: data.level || "Bronze",
        });
      }

      setLoaded(true);
    }

    loadAccount();

    return () => {
      active = false;
    };
  }, [router]);

  const totalPoints = rewards?.total_points ?? 0;
  const levelInfo = useMemo(
    () => getLevelInfo(totalPoints),
    [totalPoints]
  );

  const progress = getProgress(
    totalPoints,
    levelInfo.minimum,
    levelInfo.nextMinimum
  );

  const pointsUntilNextLevel = levelInfo.nextMinimum
    ? Math.max(levelInfo.nextMinimum - totalPoints, 0)
    : 0;

  const firstName =
    rewards?.first_name ||
    (typeof user?.user_metadata?.first_name === "string"
      ? user.user_metadata.first_name
      : "Client");

  const lastName =
    rewards?.last_name ||
    (typeof user?.user_metadata?.last_name === "string"
      ? user.user_metadata.last_name
      : "");

  async function handleSignOut() {
    if (signingOut) {
      return;
    }

    setSigningOut(true);

    const { error } = await supabase.auth.signOut();

    if (error) {
      setErrorMessage("Deconectarea nu a putut fi realizată.");
      setSigningOut(false);
      return;
    }

    router.replace("/");
    router.refresh();
  }

  if (!loaded) {
    return (
      <main className="min-h-screen bg-black text-white">
        <Header />

        <section className="mx-auto max-w-7xl px-6 py-20">
          <p className="text-center text-neutral-400">
            Se încarcă contul tău...
          </p>
        </section>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <Header />

      <section className="mx-auto max-w-7xl px-6 py-16">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.28em] text-[#D4AF37]">
              Contul meu
            </p>

            <h1 className="mt-4 text-4xl font-bold sm:text-5xl">
              Salut, {firstName} 👋
            </h1>

            <p className="mt-3 text-neutral-400">
              {user?.email}
            </p>
          </div>

          <button
            type="button"
            onClick={handleSignOut}
            disabled={signingOut}
            className="rounded-xl border border-white/15 px-6 py-3 font-semibold transition hover:border-red-400 hover:text-red-300 disabled:opacity-50"
          >
            {signingOut ? "Se deconectează..." : "Deconectare"}
          </button>
        </div>

        {errorMessage && (
          <div
            role="alert"
            className="mt-8 rounded-xl border border-red-500/40 bg-red-500/10 p-4 text-red-300"
          >
            {errorMessage}
          </div>
        )}

        {!rewards && !errorMessage && (
          <div className="mt-8 rounded-2xl border border-[#D4AF37]/30 bg-[#D4AF37]/10 p-5 text-neutral-300">
            Contul este activ. Datele VIRELLO Rewards vor apărea
            aici după prima comandă plasată cu adresa{" "}
            <strong className="text-white">{user?.email}</strong>.
          </div>
        )}

        <div className="mt-10 grid gap-6 lg:grid-cols-[1.3fr_0.7fr]">
          <section className="rounded-3xl border border-[#D4AF37]/30 bg-gradient-to-br from-[#D4AF37]/15 to-neutral-900 p-7 sm:p-9">
            <div className="flex flex-col gap-6 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <p className="text-sm font-bold uppercase tracking-[0.25em] text-[#D4AF37]">
                  VIRELLO Rewards
                </p>

                <p className="mt-4 text-5xl font-bold">
                  ⭐ {rewards?.available_points ?? 0}
                </p>

                <p className="mt-2 text-neutral-300">
                  puncte disponibile
                </p>
              </div>

              <div className="rounded-2xl border border-white/10 bg-black/30 px-6 py-5 text-center">
                <p className="text-4xl">{levelInfo.icon}</p>

                <p className="mt-2 text-xl font-bold">
                  {levelInfo.name}
                </p>

                <p className="mt-1 text-xs uppercase tracking-wider text-neutral-400">
                  Nivelul tău
                </p>
              </div>
            </div>

            <div className="mt-9">
              <div className="flex items-center justify-between gap-4 text-sm">
                <span className="font-semibold">
                  {levelInfo.name}
                </span>

                <span className="text-neutral-400">
                  {levelInfo.nextName
                    ? `${pointsUntilNextLevel} puncte până la ${levelInfo.nextName}`
                    : "Ai atins nivelul maxim"}
                </span>
              </div>

              <div className="mt-3 h-3 overflow-hidden rounded-full bg-black/50">
                <div
                  className="h-full rounded-full bg-[#D4AF37] transition-all duration-700"
                  style={{ width: `${progress}%` }}
                />
              </div>

              <div className="mt-3 flex justify-between text-xs text-neutral-500">
                <span>{levelInfo.minimum} puncte</span>

                <span>
                  {levelInfo.nextMinimum
                    ? `${levelInfo.nextMinimum} puncte`
                    : "Diamond"}
                </span>
              </div>
            </div>

            <div className="mt-8 rounded-2xl border border-white/10 bg-black/30 p-5">
              <p className="font-semibold">
                100 puncte = 10 lei reducere
              </p>

              <p className="mt-2 text-sm leading-6 text-neutral-400">
                Punctele se acordă după confirmarea și finalizarea
                comenzilor eligibile.
              </p>
            </div>
          </section>

          <section className="rounded-3xl border border-white/10 bg-neutral-900 p-7">
            <p className="text-sm font-bold uppercase tracking-[0.22em] text-neutral-400">
              Profil client
            </p>

            <p className="mt-5 text-2xl font-bold">
              {firstName} {lastName}
            </p>

            <p className="mt-2 text-neutral-400">{user?.email}</p>

            <div className="my-6 border-t border-white/10" />

            <p className="text-sm leading-6 text-neutral-400">
              Folosește aceeași adresă de email la comenzi pentru
              ca punctele și beneficiile să fie asociate automat
              contului tău.
            </p>

            <Link
              href="/Produse"
              className="mt-6 block rounded-xl bg-[#D4AF37] px-6 py-4 text-center font-bold text-black transition hover:opacity-90"
            >
              Continuă cumpărăturile
            </Link>
          </section>
        </div>

        <section className="mt-6 grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
          <article className="rounded-2xl border border-white/10 bg-neutral-900 p-6">
            <p className="text-3xl">📦</p>

            <p className="mt-4 text-3xl font-bold">
              {rewards?.orders_count ?? 0}
            </p>

            <p className="mt-1 text-sm text-neutral-400">
              Comenzi finalizate
            </p>
          </article>

          <article className="rounded-2xl border border-white/10 bg-neutral-900 p-6">
            <p className="text-3xl">💳</p>

            <p className="mt-4 text-3xl font-bold">
              {formatPrice(rewards?.lifetime_spent ?? 0)}
            </p>

            <p className="mt-1 text-sm text-neutral-400">
              Valoare totală comenzi
            </p>
          </article>

          <article className="rounded-2xl border border-white/10 bg-neutral-900 p-6">
            <p className="text-3xl">🎁</p>

            <p className="mt-4 text-3xl font-bold">
              {rewards?.gifts_received ?? 0}
            </p>

            <p className="mt-1 text-sm text-neutral-400">
              Cadouri surpriză
            </p>
          </article>

          <article className="rounded-2xl border border-white/10 bg-neutral-900 p-6">
            <p className="text-3xl">⭐</p>

            <p className="mt-4 text-3xl font-bold">
              {rewards?.total_points ?? 0}
            </p>

            <p className="mt-1 text-sm text-neutral-400">
              Puncte câștigate total
            </p>
          </article>
        </section>

        <section className="mt-6 grid gap-5 md:grid-cols-3">
          <Link
            href="/Produse"
            className="rounded-2xl border border-white/10 bg-neutral-900 p-6 transition hover:border-[#D4AF37]/60"
          >
            <p className="text-3xl">🛍️</p>
            <p className="mt-4 text-xl font-bold">Produse</p>
            <p className="mt-2 text-sm text-neutral-400">
              Descoperă toate produsele VIRELLO.
            </p>
          </Link>

          <Link
            href="/Favorite"
            className="rounded-2xl border border-white/10 bg-neutral-900 p-6 transition hover:border-[#D4AF37]/60"
          >
            <p className="text-3xl">❤️</p>
            <p className="mt-4 text-xl font-bold">Favorite</p>
            <p className="mt-2 text-sm text-neutral-400">
              Revino rapid la produsele salvate.
            </p>
          </Link>

          <Link
            href="/Cos"
            className="rounded-2xl border border-white/10 bg-neutral-900 p-6 transition hover:border-[#D4AF37]/60"
          >
            <p className="text-3xl">🛒</p>
            <p className="mt-4 text-xl font-bold">Coșul meu</p>
            <p className="mt-2 text-sm text-neutral-400">
              Continuă și finalizează cumpărăturile.
            </p>
          </Link>
        </section>
      </section>
    </main>
  );
}