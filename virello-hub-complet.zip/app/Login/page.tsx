"use client";

import Link from "next/link";
import { FormEvent, useEffect, useState } from "react";
import { useRouter } from "next/navigation";

import Header from "@/components/Header";
import { supabase } from "@/lib/supabase/client";

type Mode = "login" | "register";

export default function LoginPage() {
  const router = useRouter();

  const [mode, setMode] = useState<Mode>("login");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [loaded, setLoaded] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    let active = true;

    async function checkSession() {
      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!active) {
        return;
      }

      if (session?.user) {
        router.replace("/Cont");
        return;
      }

      setLoaded(true);
    }

    checkSession();

    return () => {
      active = false;
    };
  }, [router]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (submitting) {
      return;
    }

    setSubmitting(true);
    setErrorMessage("");
    setSuccessMessage("");

    const normalizedEmail = email.trim().toLowerCase();

    if (mode === "login") {
      const { error } = await supabase.auth.signInWithPassword({
        email: normalizedEmail,
        password,
      });

      if (error) {
        setErrorMessage(
          error.message === "Invalid login credentials"
            ? "Emailul sau parola nu sunt corecte."
            : error.message
        );

        setSubmitting(false);
        return;
      }

      router.replace("/Cont");
      router.refresh();
      return;
    }

    if (!firstName.trim() || !lastName.trim()) {
      setErrorMessage("Completează numele și prenumele.");
      setSubmitting(false);
      return;
    }

    const { data, error } = await supabase.auth.signUp({
      email: normalizedEmail,
      password,
      options: {
        data: {
          first_name: firstName.trim(),
          last_name: lastName.trim(),
        },
      },
    });

    if (error) {
      setErrorMessage(error.message);
      setSubmitting(false);
      return;
    }

    if (data.session) {
      router.replace("/Cont");
      router.refresh();
      return;
    }

    setSuccessMessage(
      "Contul a fost creat. Verifică emailul și apasă linkul de confirmare, apoi autentifică-te."
    );

    setMode("login");
    setPassword("");
    setSubmitting(false);
  }

  function changeMode(nextMode: Mode) {
    setMode(nextMode);
    setErrorMessage("");
    setSuccessMessage("");
  }

  if (!loaded) {
    return (
      <main className="min-h-screen bg-black text-white">
        <Header />

        <section className="mx-auto max-w-3xl px-6 py-20 text-center">
          <p className="text-neutral-400">Se încarcă...</p>
        </section>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <Header />

      <section className="mx-auto max-w-6xl px-6 py-16">
        <div className="grid overflow-hidden rounded-3xl border border-white/10 bg-neutral-900 lg:grid-cols-2">
          <div className="border-b border-white/10 p-8 sm:p-12 lg:border-b-0 lg:border-r">
            <p className="text-sm font-bold uppercase tracking-[0.28em] text-[#D4AF37]">
              VIRELLO Rewards
            </p>

            <h1 className="mt-5 text-4xl font-bold sm:text-5xl">
              {mode === "login"
                ? "Bine ai revenit"
                : "Creează-ți contul"}
            </h1>

            <p className="mt-5 max-w-xl leading-7 text-neutral-400">
              Autentifică-te pentru a vedea punctele, nivelul,
              comenzile și beneficiile tale VIRELLO.
            </p>

            <div className="mt-9 space-y-4">
              <div className="rounded-2xl border border-[#D4AF37]/25 bg-[#D4AF37]/10 p-5">
                <p className="font-semibold text-white">
                  ⭐ Puncte la fiecare comandă
                </p>

                <p className="mt-2 text-sm leading-6 text-neutral-300">
                  Primești 1 punct pentru fiecare 10 lei cheltuiți.
                </p>
              </div>

              <div className="rounded-2xl border border-white/10 bg-black/30 p-5">
                <p className="font-semibold text-white">
                  🏆 Niveluri și beneficii
                </p>

                <p className="mt-2 text-sm leading-6 text-neutral-400">
                  Bronze, Silver, Gold și Diamond, cu avantaje
                  dedicate clienților fideli.
                </p>
              </div>

              <div className="rounded-2xl border border-white/10 bg-black/30 p-5">
                <p className="font-semibold text-white">
                  📦 Totul într-un singur loc
                </p>

                <p className="mt-2 text-sm leading-6 text-neutral-400">
                  Urmărești punctele, comenzile și cadourile
                  primite direct din cont.
                </p>
              </div>
            </div>
          </div>

          <div className="p-8 sm:p-12">
            <div className="grid grid-cols-2 rounded-xl bg-black p-1">
              <button
                type="button"
                onClick={() => changeMode("login")}
                className={`rounded-lg px-4 py-3 font-semibold transition ${
                  mode === "login"
                    ? "bg-[#D4AF37] text-black"
                    : "text-neutral-400 hover:text-white"
                }`}
              >
                Autentificare
              </button>

              <button
                type="button"
                onClick={() => changeMode("register")}
                className={`rounded-lg px-4 py-3 font-semibold transition ${
                  mode === "register"
                    ? "bg-[#D4AF37] text-black"
                    : "text-neutral-400 hover:text-white"
                }`}
              >
                Cont nou
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-8 space-y-5">
              {mode === "register" && (
                <div className="grid gap-5 sm:grid-cols-2">
                  <label className="space-y-2">
                    <span className="text-sm text-neutral-300">
                      Prenume
                    </span>

                    <input
                      required
                      type="text"
                      value={firstName}
                      onChange={(event) =>
                        setFirstName(event.target.value)
                      }
                      autoComplete="given-name"
                      placeholder="Andrei"
                      className="w-full rounded-xl border border-white/15 bg-black px-4 py-4 outline-none transition placeholder:text-neutral-600 focus:border-[#D4AF37]"
                    />
                  </label>

                  <label className="space-y-2">
                    <span className="text-sm text-neutral-300">
                      Nume
                    </span>

                    <input
                      required
                      type="text"
                      value={lastName}
                      onChange={(event) =>
                        setLastName(event.target.value)
                      }
                      autoComplete="family-name"
                      placeholder="Popescu"
                      className="w-full rounded-xl border border-white/15 bg-black px-4 py-4 outline-none transition placeholder:text-neutral-600 focus:border-[#D4AF37]"
                    />
                  </label>
                </div>
              )}

              <label className="block space-y-2">
                <span className="text-sm text-neutral-300">
                  Email
                </span>

                <input
                  required
                  type="email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  autoComplete="email"
                  placeholder="andrei@email.ro"
                  className="w-full rounded-xl border border-white/15 bg-black px-4 py-4 outline-none transition placeholder:text-neutral-600 focus:border-[#D4AF37]"
                />
              </label>

              <label className="block space-y-2">
                <span className="text-sm text-neutral-300">
                  Parolă
                </span>

                <input
                  required
                  type="password"
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  autoComplete={
                    mode === "login"
                      ? "current-password"
                      : "new-password"
                  }
                  minLength={6}
                  placeholder="Minimum 6 caractere"
                  className="w-full rounded-xl border border-white/15 bg-black px-4 py-4 outline-none transition placeholder:text-neutral-600 focus:border-[#D4AF37]"
                />
              </label>

              {errorMessage && (
                <div
                  role="alert"
                  className="rounded-xl border border-red-500/40 bg-red-500/10 p-4 text-sm text-red-300"
                >
                  {errorMessage}
                </div>
              )}

              {successMessage && (
                <div className="rounded-xl border border-green-500/40 bg-green-500/10 p-4 text-sm leading-6 text-green-300">
                  {successMessage}
                </div>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="w-full rounded-xl bg-[#D4AF37] px-6 py-4 font-bold text-black transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {submitting
                  ? "Se procesează..."
                  : mode === "login"
                    ? "Intră în cont"
                    : "Creează contul"}
              </button>
            </form>

            <p className="mt-6 text-center text-sm text-neutral-500">
              Continuând, accepți condițiile magazinului și
              politica de confidențialitate.
            </p>

            <Link
              href="/"
              className="mt-5 block text-center text-sm text-neutral-400 transition hover:text-[#D4AF37]"
            >
              ← Înapoi la magazin
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}