import Link from "next/link";
import AddToCartButton from "../../components/AddToCartButton";
import FavoriteButton from "../../components/FavoriteButton";

type ProductPageProps = {
  params: Promise<{
    id: string;
  }>;
};

const products = [
  {
    id: 1,
    slug: "lampa-led-premium",
    name: "Lampă LED Premium",
    category: "Casă & Grădină",
    price: "149,99 lei",
    oldPrice: "189,99 lei",
    badge: "Reducere",
    rating: "4.9",
    reviews: 124,
    description:
      "O lampă modernă și elegantă, concepută pentru a crea o atmosferă plăcută în orice încăpere. Designul minimalist o face potrivită pentru dormitor, birou sau living.",
  },
  {
    id: 2,
    slug: "suport-auto-magnetic",
    name: "Suport Auto Magnetic",
    category: "Auto",
    price: "79,99 lei",
    oldPrice: "99,99 lei",
    badge: "Popular",
    rating: "4.8",
    reviews: 96,
    description:
      "Suport magnetic compact pentru telefon, potrivit pentru utilizarea zilnică în mașină. Oferă acces rapid la navigație și menține telefonul într-o poziție stabilă.",
  },
  {
    id: 3,
    slug: "mini-aspirator-portabil",
    name: "Mini Aspirator Portabil",
    category: "Gadgeturi",
    price: "129,99 lei",
    oldPrice: "159,99 lei",
    badge: "Nou",
    rating: "4.7",
    reviews: 78,
    description:
      "Un aspirator compact și ușor de utilizat, ideal pentru curățarea rapidă a biroului, mașinii sau spațiilor greu accesibile.",
  },
  {
    id: 4,
    slug: "sticla-termica-eleganta",
    name: "Sticlă Termică Elegantă",
    category: "Sport",
    price: "89,99 lei",
    oldPrice: "109,99 lei",
    badge: "Bestseller",
    rating: "4.9",
    reviews: 143,
    description:
      "Sticlă termică elegantă, potrivită pentru birou, călătorii și activități sportive. Ajută la păstrarea temperaturii băuturilor pentru mai mult timp.",
  },
  {
    id: 5,
    slug: "organizator-multifunctional",
    name: "Organizator Multifuncțional",
    category: "Casă & Grădină",
    price: "119,99 lei",
    oldPrice: "149,99 lei",
    badge: "Recomandat",
    rating: "4.8",
    reviews: 87,
    description:
      "Organizator practic pentru păstrarea obiectelor într-un mod ordonat și accesibil. Potrivit pentru casă, birou sau spații de depozitare.",
  },
  {
    id: 6,
    slug: "aparat-de-masaj-compact",
    name: "Aparat de Masaj Compact",
    category: "Îngrijire",
    price: "179,99 lei",
    oldPrice: "219,99 lei",
    badge: "Ofertă",
    rating: "4.8",
    reviews: 112,
    description:
      "Aparat compact creat pentru momente de relaxare acasă sau în călătorii. Designul portabil îl face ușor de transportat și utilizat.",
  },
  {
    id: 7,
    slug: "casti-wireless-premium",
    name: "Căști Wireless Premium",
    category: "Gadgeturi",
    price: "199,99 lei",
    oldPrice: "249,99 lei",
    badge: "Nou",
    rating: "4.9",
    reviews: 156,
    description:
      "Căști wireless cu design modern, potrivite pentru muzică, apeluri și activități zilnice. Oferă libertate de mișcare și o experiență confortabilă.",
  },
  {
    id: 8,
    slug: "set-cadou-elegant",
    name: "Set Cadou Elegant",
    category: "Cadouri",
    price: "139,99 lei",
    oldPrice: "169,99 lei",
    badge: "Cadou",
    rating: "4.7",
    reviews: 64,
    description:
      "Un set elegant, potrivit pentru aniversări, sărbători sau alte momente speciale. Prezentarea premium îl transformă într-un cadou memorabil.",
  },
];

export default async function ProductPage({
  params,
}: ProductPageProps) {
  const { id } = await params;

  const existingProduct = products.find(
    (product) => product.slug === id
  );

  const generatedName = id
    .split("-")
    .map(
      (word) =>
        word.charAt(0).toUpperCase() + word.slice(1)
    )
    .join(" ");

  const product = existingProduct ?? {
    id: 999,
    slug: id,
    name: generatedName,
    category: "Produse VIRELLO",
    price: "149,99 lei",
    oldPrice: "189,99 lei",
    badge: "Recomandat",
    rating: "4.8",
    reviews: 50,
    description:
      "Produs modern și util, selectat pentru magazinul VIRELLO. Informațiile comerciale complete vor fi adăugate înainte de lansare.",
  };

  return (
    <main className="min-h-screen bg-black text-white">
      <section className="border-b border-white/10 bg-neutral-950">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-2 px-6 py-5 text-sm text-neutral-400">
          <Link
            href="/"
            className="transition hover:text-[#D4AF37]"
          >
            Acasă
          </Link>

          <span>/</span>

          <Link
            href="/Produse"
            className="transition hover:text-[#D4AF37]"
          >
            Produse
          </Link>

          <span>/</span>

          <span className="text-white">{product.name}</span>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-12 sm:py-16">
        <div className="grid gap-12 lg:grid-cols-2">
          <div className="space-y-4">
            <div className="relative flex min-h-[430px] items-center justify-center overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-neutral-800 to-neutral-950 sm:min-h-[560px]">
              <span className="absolute left-5 top-5 rounded-full bg-[#D4AF37] px-4 py-2 text-sm font-bold text-black">
                {product.badge}
              </span>

              <FavoriteButton product={product} />

              <div className="text-center text-neutral-600">
                <div className="text-8xl">◇</div>

                <p className="mt-4 text-sm">
                  Imaginea produsului va fi adăugată la final
                </p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              {[1, 2, 3].map((item) => (
                <div
                  key={item}
                  className="flex aspect-square items-center justify-center rounded-2xl border border-white/10 bg-neutral-900 text-3xl text-neutral-700 transition hover:border-[#D4AF37]/60"
                >
                  ◇
                </div>
              ))}
            </div>
          </div>

          <div className="flex flex-col justify-center">
            <p className="text-sm font-semibold uppercase tracking-[0.3em] text-[#D4AF37]">
              {product.category}
            </p>

            <h1 className="mt-4 text-4xl font-bold leading-tight sm:text-5xl">
              {product.name}
            </h1>

            <div className="mt-5 flex flex-wrap items-center gap-3">
              <div className="text-[#D4AF37]">
                ★ ★ ★ ★ ★
              </div>

              <p className="text-sm text-neutral-400">
                {product.rating}/5 din {product.reviews} recenzii
              </p>
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <p className="text-4xl font-bold text-[#D4AF37]">
                {product.price}
              </p>

              <p className="text-lg text-neutral-500 line-through">
                {product.oldPrice}
              </p>
            </div>

            <div className="mt-5 inline-flex w-fit items-center gap-2 rounded-full border border-green-500/30 bg-green-500/10 px-4 py-2 text-sm font-semibold text-green-400">
              <span className="h-2 w-2 rounded-full bg-green-400" />
              În stoc
            </div>

            <p className="mt-8 leading-8 text-neutral-300">
              {product.description}
            </p>

            <div className="mt-8 rounded-2xl border border-white/10 bg-neutral-950 p-5">
              <p className="font-semibold text-white">
                Ce primești:
              </p>

              <ul className="mt-4 space-y-3 text-sm text-neutral-400">
                <li className="flex gap-3">
                  <span className="text-[#D4AF37]">✓</span>
                  Produs atent selectat
                </li>

                <li className="flex gap-3">
                  <span className="text-[#D4AF37]">✓</span>
                  Ambalare sigură pentru transport
                </li>

                <li className="flex gap-3">
                  <span className="text-[#D4AF37]">✓</span>
                  Asistență pentru comanda ta
                </li>
              </ul>
            </div>

            <div className="mt-8">
              <AddToCartButton
                id={product.slug}
                name={product.name}
                price={product.price}
              />
            </div>

            <div className="mt-8 grid gap-4 sm:grid-cols-3">
              <div className="rounded-2xl border border-white/10 bg-neutral-950 p-4">
                <div className="text-2xl">🚚</div>

                <p className="mt-3 font-semibold">
                  Livrare sigură
                </p>

                <p className="mt-1 text-sm text-neutral-500">
                  Expediere cu grijă
                </p>
              </div>

              <div className="rounded-2xl border border-white/10 bg-neutral-950 p-4">
                <div className="text-2xl">🔒</div>

                <p className="mt-3 font-semibold">
                  Plată protejată
                </p>

                <p className="mt-1 text-sm text-neutral-500">
                  Comandă în siguranță
                </p>
              </div>

              <div className="rounded-2xl border border-white/10 bg-neutral-950 p-4">
                <div className="text-2xl">↩️</div>

                <p className="mt-3 font-semibold">
                  Retur simplu
                </p>

                <p className="mt-1 text-sm text-neutral-500">
                  Conform condițiilor
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-16 grid gap-6 lg:grid-cols-3">
          <section className="rounded-3xl border border-white/10 bg-neutral-950 p-7">
            <h2 className="text-xl font-bold text-[#D4AF37]">
              Descriere
            </h2>

            <p className="mt-4 leading-7 text-neutral-400">
              {product.description}
            </p>
          </section>

          <section className="rounded-3xl border border-white/10 bg-neutral-950 p-7">
            <h2 className="text-xl font-bold text-[#D4AF37]">
              Livrare
            </h2>

            <p className="mt-4 leading-7 text-neutral-400">
              Comenzile sunt pregătite și expediate în condiții
              de siguranță. Perioada exactă de livrare va fi
              afișată înainte de finalizarea comenzii.
            </p>
          </section>

          <section className="rounded-3xl border border-white/10 bg-neutral-950 p-7">
            <h2 className="text-xl font-bold text-[#D4AF37]">
              Retur
            </h2>

            <p className="mt-4 leading-7 text-neutral-400">
              Produsele eligibile pot fi returnate în termenul
              prevăzut în politica magazinului și în legislația
              aplicabilă.
            </p>
          </section>
        </div>
      </section>
    </main>
  );
}