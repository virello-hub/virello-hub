"use client";

import Link from "next/link";
import { FormEvent, useEffect, useState } from "react";
import { useRouter } from "next/navigation";

import { supabase } from "@/lib/supabase/client";

export default function AdminLoginPage() {
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [loaded, setLoaded] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    let active = true;

    async function checkSession() {
      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!active) {
        return;
      }

      if (session?.user) {
        router.replace("/admin");
        return;
      }

      setLoaded(true);
    }

    checkSession();

    return () => {
      active = false;
    };
  }, [router]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (submitting) {
      return;
    }

    setSubmitting(true);
    setErrorMessage("");

    const normalizedEmail = email.trim().toLowerCase();

    const { error } = await supabase.auth.signInWithPassword({
      email: normalizedEmail,
      password,
    });

    if (error) {
      setErrorMessage(
        error.message === "Invalid login credentials"
          ? "Emailul sau parola nu sunt corecte."
          : error.message
      );

      setSubmitting(false);
      return;
    }

    router.replace("/admin");
    router.refresh();
  }

  if (!loaded) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-black px-6 text-white">
        <p className="text-neutral-400">Se încarcă...</p>
      </main>
    );
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-black px-6 py-16 text-white">
      <section className="w-full max-w-md rounded-3xl border border-white/10 bg-neutral-900 p-8 shadow-2xl sm:p-10">
        <div className="text-center">
          <p className="text-sm font-bold uppercase tracking-[0.3em] text-[#D4AF37]">
            VIRELLO
          </p>

          <h1 className="mt-4 text-3xl font-bold">
            Administrare
          </h1>

          <p className="mt-3 text-sm leading-6 text-neutral-400">
            Autentifică-te pentru a accesa panoul de administrare.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="mt-8 space-y-5">
          <label className="block space-y-2">
            <span className="text-sm text-neutral-300">
              Email administrator
            </span>

            <input
              required
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              autoComplete="email"
              placeholder="admin@email.ro"
              className="w-full rounded-xl border border-white/15 bg-black px-4 py-4 outline-none transition placeholder:text-neutral-600 focus:border-[#D4AF37]"
            />
          </label>

          <label className="block space-y-2">
            <span className="text-sm text-neutral-300">
              Parolă
            </span>

            <input
              required
              type="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              autoComplete="current-password"
              placeholder="Parola administratorului"
              className="w-full rounded-xl border border-white/15 bg-black px-4 py-4 outline-none transition placeholder:text-neutral-600 focus:border-[#D4AF37]"
            />
          </label>

          {errorMessage && (
            <div
              role="alert"
              className="rounded-xl border border-red-500/40 bg-red-500/10 p-4 text-sm text-red-300"
            >
              {errorMessage}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full rounded-xl bg-[#D4AF37] px-6 py-4 font-bold text-black transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {submitting
              ? "Se autentifică..."
              : "Intră în administrare"}
          </button>
        </form>

        <Link
          href="/"
          className="mt-6 block text-center text-sm text-neutral-400 transition hover:text-[#D4AF37]"
        >
          ← Înapoi la magazin
        </Link>
      </section>
    </main>
  );
}