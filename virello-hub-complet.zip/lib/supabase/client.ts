import { createBrowserClient } from "@supabase/ssr";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabasePublishableKey =
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

if (!supabaseUrl) {
  throw new Error(
    "Lipsește variabila NEXT_PUBLIC_SUPABASE_URL din fișierul .env.local."
  );
}

if (!supabasePublishableKey) {
  throw new Error(
    "Lipsește variabila NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY din fișierul .env.local."
  );
}

export const supabase = createBrowserClient(
  supabaseUrl,
  supabasePublishableKey
);