"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import Header from "../components/Header";

type CartProduct = {
  id: string;
  name: string;
  price: string;
  quantity: number;
};

const FREE_DELIVERY_THRESHOLD = 249.99;
const SURPRISE_GIFT_THRESHOLD = 299.99;
const DELIVERY_PRICE = 19.99;

function priceToNumber(price: string) {
  const normalizedPrice = price
    .replace(/\s/g, "")
    .replace(/lei/gi, "")
    .replace(/\./g, "")
    .replace(",", ".");

  const value = Number(normalizedPrice);

  return Number.isFinite(value) ? value : 0;
}

function formatPrice(price: number) {
  return `${price.toFixed(2).replace(".", ",")} lei`;
}

function calculateLoyaltyPoints(value: number) {
  return Math.floor(value / 10);
}

function getProgressPercentage(current: number, target: number) {
  if (current <= 0) {
    return 0;
  }

  return Math.min((current / target) * 100, 100);
}

export default function CartPage() {
  const [cart, setCart] = useState<CartProduct[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    try {
      const savedCart = localStorage.getItem("virello-cart");

      if (savedCart) {
        const parsedCart = JSON.parse(savedCart);

        if (Array.isArray(parsedCart)) {
          setCart(parsedCart);
        }
      }
    } catch {
      localStorage.removeItem("virello-cart");
    }

    setLoaded(true);
  }, []);

  function saveCart(updatedCart: CartProduct[]) {
    setCart(updatedCart);
    localStorage.setItem(
      "virello-cart",
      JSON.stringify(updatedCart)
    );
  }

  function increaseQuantity(id: string) {
    const updatedCart = cart.map((product) =>
      product.id === id
        ? {
            ...product,
            quantity: product.quantity + 1,
          }
        : product
    );

    saveCart(updatedCart);
  }

  function decreaseQuantity(id: string) {
    const updatedCart = cart
      .map((product) =>
        product.id === id
          ? {
              ...product,
              quantity: product.quantity - 1,
            }
          : product
      )
      .filter((product) => product.quantity > 0);

    saveCart(updatedCart);
  }

  function removeProduct(id: string) {
    const updatedCart = cart.filter(
      (product) => product.id !== id
    );

    saveCart(updatedCart);
  }

  function clearCart() {
    setCart([]);
    localStorage.removeItem("virello-cart");
  }

  const subtotal = cart.reduce(
    (total, product) =>
      total +
      priceToNumber(product.price) * product.quantity,
    0
  );

  const hasFreeDelivery =
    subtotal >= FREE_DELIVERY_THRESHOLD;

  const hasSurpriseGift =
    subtotal >= SURPRISE_GIFT_THRESHOLD;

  const delivery = hasFreeDelivery
    ? 0
    : DELIVERY_PRICE;

  const total = subtotal + delivery;

  const loyaltyPoints =
    calculateLoyaltyPoints(subtotal);

  const amountUntilFreeDelivery = Math.max(
    FREE_DELIVERY_THRESHOLD - subtotal,
    0
  );

  const amountUntilGift = Math.max(
    SURPRISE_GIFT_THRESHOLD - subtotal,
    0
  );

  const freeDeliveryProgress =
    getProgressPercentage(
      subtotal,
      FREE_DELIVERY_THRESHOLD
    );

  const surpriseGiftProgress =
    getProgressPercentage(
      subtotal,
      SURPRISE_GIFT_THRESHOLD
    );

  if (!loaded) {
    return (
      <main className="min-h-screen bg-black text-white">
        <Header />
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <Header />

      <section className="mx-auto max-w-7xl px-6 py-16">
        <p className="text-sm uppercase tracking-[0.3em] text-[#D4AF37]">
          VIRELLO
        </p>

        <h1 className="mt-4 text-4xl font-bold sm:text-5xl">
          Coșul tău
        </h1>

        <p className="mt-4 max-w-2xl text-neutral-400">
          Completează comanda și bucură-te de beneficii
          exclusive prin programul VIRELLO Rewards.
        </p>

        {cart.length === 0 ? (
          <div className="mt-12 rounded-3xl border border-white/10 bg-neutral-900 p-10 text-center">
            <p className="text-2xl font-semibold">
              Coșul este gol
            </p>

            <p className="mt-3 text-neutral-400">
              Adaugă un produs pentru a-l vedea aici.
            </p>

            <Link
              href="/"
              className="mt-8 inline-block rounded-xl bg-[#D4AF37] px-7 py-4 font-bold text-black transition hover:opacity-90"
            >
              Vezi produsele
            </Link>
          </div>
        ) : (
          <>
            <div className="mt-10 grid gap-5 md:grid-cols-2">
              <div className="rounded-3xl border border-[#D4AF37]/30 bg-[#D4AF37]/10 p-6">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <p className="text-sm font-bold uppercase tracking-wider text-[#D4AF37]">
                      Transport gratuit
                    </p>

                    {hasFreeDelivery ? (
                      <p className="mt-2 font-semibold text-white">
                        Ai transport gratuit la această
                        comandă.
                      </p>
                    ) : (
                      <p className="mt-2 text-neutral-300">
                        Mai adaugă produse de{" "}
                        <strong className="text-white">
                          {formatPrice(
                            amountUntilFreeDelivery
                          )}
                        </strong>{" "}
                        pentru transport gratuit.
                      </p>
                    )}
                  </div>

                  <span className="text-3xl">🚚</span>
                </div>

                <div className="mt-5 h-2 overflow-hidden rounded-full bg-black/40">
                  <div
                    className="h-full rounded-full bg-[#D4AF37] transition-all duration-500"
                    style={{
                      width: `${freeDeliveryProgress}%`,
                    }}
                  />
                </div>

                <p className="mt-2 text-right text-xs text-neutral-400">
                  Prag:{" "}
                  {formatPrice(
                    FREE_DELIVERY_THRESHOLD
                  )}
                </p>
              </div>

              <div className="rounded-3xl border border-purple-400/30 bg-purple-400/10 p-6">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <p className="text-sm font-bold uppercase tracking-wider text-purple-300">
                      Cadou surpriză VIRELLO
                    </p>

                    {hasSurpriseGift ? (
                      <p className="mt-2 font-semibold text-white">
                        Felicitări! Comanda ta include un
                        cadou surpriză.
                      </p>
                    ) : (
                      <p className="mt-2 text-neutral-300">
                        Mai ai doar{" "}
                        <strong className="text-white">
                          {formatPrice(amountUntilGift)}
                        </strong>{" "}
                        până la cadoul surpriză oferit de
                        VIRELLO.
                      </p>
                    )}
                  </div>

                  <span className="text-3xl">🎁</span>
                </div>

                <div className="mt-5 h-2 overflow-hidden rounded-full bg-black/40">
                  <div
                    className="h-full rounded-full bg-purple-300 transition-all duration-500"
                    style={{
                      width: `${surpriseGiftProgress}%`,
                    }}
                  />
                </div>

                <p className="mt-2 text-right text-xs text-neutral-400">
                  Prag:{" "}
                  {formatPrice(
                    SURPRISE_GIFT_THRESHOLD
                  )}
                </p>
              </div>
            </div>

            <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_380px]">
              <div className="space-y-5">
                {cart.map((product) => {
                  const productPrice =
                    priceToNumber(product.price);

                  const productTotal =
                    productPrice * product.quantity;

                  const productPoints =
                    calculateLoyaltyPoints(
                      productTotal
                    );

                  return (
                    <div
                      key={product.id}
                      className="rounded-3xl border border-white/10 bg-neutral-900 p-6"
                    >
                      <div className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                          <Link
                            href={`/produs/${product.id}`}
                            className="text-xl font-bold transition hover:text-[#D4AF37]"
                          >
                            {product.name}
                          </Link>

                          <p className="mt-2 text-neutral-400">
                            {product.price} / bucată
                          </p>

                          <p className="mt-2 text-sm font-semibold text-[#D4AF37]">
                            ⭐ Primești aproximativ{" "}
                            {productPoints} puncte VIRELLO
                          </p>
                        </div>

                        <div className="flex flex-wrap items-center gap-4">
                          <div className="flex items-center overflow-hidden rounded-xl border border-white/15">
                            <button
                              type="button"
                              onClick={() =>
                                decreaseQuantity(
                                  product.id
                                )
                              }
                              className="h-11 w-11 text-xl transition hover:bg-white hover:text-black"
                              aria-label={`Scade cantitatea pentru ${product.name}`}
                            >
                              −
                            </button>

                            <span className="flex h-11 min-w-12 items-center justify-center border-x border-white/15 font-bold">
                              {product.quantity}
                            </span>

                            <button
                              type="button"
                              onClick={() =>
                                increaseQuantity(
                                  product.id
                                )
                              }
                              className="h-11 w-11 text-xl transition hover:bg-white hover:text-black"
                              aria-label={`Crește cantitatea pentru ${product.name}`}
                            >
                              +
                            </button>
                          </div>

                          <p className="min-w-28 text-right text-xl font-bold text-[#D4AF37]">
                            {formatPrice(productTotal)}
                          </p>

                          <button
                            type="button"
                            onClick={() =>
                              removeProduct(product.id)
                            }
                            className="rounded-xl border border-red-500/50 px-4 py-2 text-red-400 transition hover:bg-red-500 hover:text-white"
                          >
                            Șterge
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}

                <button
                  type="button"
                  onClick={clearCart}
                  className="rounded-xl border border-white/20 px-6 py-3 font-semibold transition hover:border-white"
                >
                  Golește coșul
                </button>
              </div>

              <aside className="h-fit rounded-3xl border border-white/10 bg-neutral-900 p-7">
                <h2 className="text-2xl font-bold">
                  Sumar comandă
                </h2>

                <div className="mt-7 space-y-4 text-neutral-300">
                  <div className="flex justify-between gap-4">
                    <span>Subtotal</span>
                    <span>
                      {formatPrice(subtotal)}
                    </span>
                  </div>

                  <div className="flex justify-between gap-4">
                    <span>Livrare</span>

                    <span
                      className={
                        delivery === 0
                          ? "font-bold text-green-400"
                          : ""
                      }
                    >
                      {delivery === 0
                        ? "Gratuită"
                        : formatPrice(delivery)}
                    </span>
                  </div>

                  <div className="flex justify-between gap-4">
                    <span>Cadou surpriză</span>

                    <span
                      className={
                        hasSurpriseGift
                          ? "font-bold text-purple-300"
                          : "text-neutral-500"
                      }
                    >
                      {hasSurpriseGift
                        ? "Inclus"
                        : "Neactivat"}
                    </span>
                  </div>
                </div>

                <div className="mt-6 rounded-2xl border border-[#D4AF37]/30 bg-[#D4AF37]/10 p-5">
                  <p className="text-sm font-bold uppercase tracking-wider text-[#D4AF37]">
                    VIRELLO Rewards
                  </p>

                  <p className="mt-3 text-3xl font-bold text-white">
                    ⭐ {loyaltyPoints} puncte
                  </p>

                  <p className="mt-2 text-sm leading-6 text-neutral-300">
                    Punctele estimate pentru această
                    comandă. Primești 1 punct pentru fiecare
                    10 lei cheltuiți.
                  </p>

                  <p className="mt-3 text-xs text-neutral-500">
                    Punctele se acordă după confirmarea și
                    finalizarea comenzii.
                  </p>
                </div>

                <div className="my-7 border-t border-white/10" />

                <div className="flex justify-between gap-4 text-xl font-bold">
                  <span>Total</span>

                  <span className="text-[#D4AF37]">
                    {formatPrice(total)}
                  </span>
                </div>

                <Link
                  href="/Comanda"
                  className="mt-7 block w-full rounded-xl bg-[#D4AF37] px-6 py-4 text-center font-bold text-black transition hover:opacity-90"
                >
                  Continuă către comandă
                </Link>

                <p className="mt-4 text-center text-sm text-neutral-500">
                  Plata și datele de livrare se completează
                  la pasul următor.
                </p>
              </aside>
            </div>

            <section className="mt-12 rounded-3xl border border-white/10 bg-neutral-900 p-7 sm:p-9">
              <div className="max-w-3xl">
                <p className="text-sm font-bold uppercase tracking-[0.25em] text-[#D4AF37]">
                  Program de fidelitate
                </p>

                <h2 className="mt-3 text-3xl font-bold">
                  Descoperă nivelurile VIRELLO Rewards
                </h2>

                <p className="mt-4 leading-7 text-neutral-400">
                  Cu fiecare comandă acumulezi puncte și
                  deblochezi beneficii create pentru
                  clienții noștri fideli.
                </p>
              </div>

              <div className="mt-8 grid gap-5 md:grid-cols-3">
                <article className="rounded-2xl border border-orange-300/30 bg-orange-300/5 p-6">
                  <p className="text-sm font-bold uppercase tracking-wider text-orange-300">
                    Bronze
                  </p>

                  <p className="mt-2 text-2xl font-bold">
                    0 – 499 puncte
                  </p>

                  <p className="mt-4 leading-6 text-neutral-400">
                    Acumulezi puncte la fiecare comandă și
                    ai acces la beneficiile de bază VIRELLO
                    Rewards.
                  </p>
                </article>

                <article className="rounded-2xl border border-neutral-300/30 bg-neutral-300/5 p-6">
                  <p className="text-sm font-bold uppercase tracking-wider text-neutral-300">
                    Silver
                  </p>

                  <p className="mt-2 text-2xl font-bold">
                    500 – 1.499 puncte
                  </p>

                  <p className="mt-4 leading-6 text-neutral-400">
                    Primești acces prioritar la promoții
                    selectate și oferte dedicate membrilor
                    Silver.
                  </p>
                </article>

                <article className="rounded-2xl border border-[#D4AF37]/40 bg-[#D4AF37]/5 p-6">
                  <p className="text-sm font-bold uppercase tracking-wider text-[#D4AF37]">
                    Gold
                  </p>

                  <p className="mt-2 text-2xl font-bold">
                    1.500+ puncte
                  </p>

                  <p className="mt-4 leading-6 text-neutral-400">
                    Deblochezi campanii exclusive, acces
                    prioritar la lansări și cadouri surpriză
                    în perioade speciale.
                  </p>
                </article>
              </div>

              <div className="mt-7 rounded-2xl border border-white/10 bg-black/30 p-5">
                <p className="font-semibold text-white">
                  100 puncte VIRELLO = 10 lei reducere
                </p>

                <p className="mt-2 text-sm leading-6 text-neutral-400">
                  Reducerea poate fi folosită la o comandă
                  viitoare, după acumularea numărului minim
                  de puncte.
                </p>
              </div>
            </section>
          </>
        )}
      </section>
    </main>
  );
}