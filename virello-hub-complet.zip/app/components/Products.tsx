"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import FavoriteButton from "./FavoriteButton";

const products = [
  {
    id: 1,
    slug: "lampa-led-premium",
    name: "Lampă LED Premium",
    category: "Casă & Grădină",
    price: "149,99 lei",
    oldPrice: "189,99 lei",
    badge: "Reducere",
  },
  {
    id: 2,
    slug: "suport-auto-magnetic",
    name: "Suport Auto Magnetic",
    category: "Auto",
    price: "79,99 lei",
    oldPrice: "99,99 lei",
    badge: "Popular",
  },
  {
    id: 3,
    slug: "mini-aspirator-portabil",
    name: "Mini Aspirator Portabil",
    category: "Gadgeturi",
    price: "129,99 lei",
    oldPrice: "159,99 lei",
    badge: "Nou",
  },
  {
    id: 4,
    slug: "sticla-termica-eleganta",
    name: "Sticlă Termică Elegantă",
    category: "Sport",
    price: "89,99 lei",
    oldPrice: "109,99 lei",
    badge: "Bestseller",
  },
  {
    id: 5,
    slug: "organizator-multifunctional",
    name: "Organizator Multifuncțional",
    category: "Casă & Grădină",
    price: "119,99 lei",
    oldPrice: "149,99 lei",
    badge: "Recomandat",
  },
  {
    id: 6,
    slug: "aparat-de-masaj-compact",
    name: "Aparat de Masaj Compact",
    category: "Îngrijire",
    price: "179,99 lei",
    oldPrice: "219,99 lei",
    badge: "Ofertă",
  },
  {
    id: 7,
    slug: "casti-wireless-premium",
    name: "Căști Wireless Premium",
    category: "Gadgeturi",
    price: "199,99 lei",
    oldPrice: "249,99 lei",
    badge: "Nou",
  },
  {
    id: 8,
    slug: "set-cadou-elegant",
    name: "Set Cadou Elegant",
    category: "Cadouri",
    price: "139,99 lei",
    oldPrice: "169,99 lei",
    badge: "Cadou",
  },
];

const categories = [
  "Toate",
  "Casă & Grădină",
  "Auto",
  "Gadgeturi",
  "Sport",
  "Îngrijire",
  "Cadouri",
];

function normalizeText(text: string) {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function getNumericPrice(price: string) {
  return Number(
    price
      .replace(" lei", "")
      .replace(/\./g, "")
      .replace(",", ".")
  );
}

export default function Products() {
  const searchParams = useSearchParams();

  const searchQuery = searchParams.get("cautare")?.trim() || "";

  const [selectedCategory, setSelectedCategory] = useState("Toate");
  const [sortOption, setSortOption] = useState("recomandate");

  const filteredProducts = useMemo(() => {
    const normalizedSearch = normalizeText(searchQuery);

    const result = products.filter((product) => {
      const matchesSearch =
        !normalizedSearch ||
        normalizeText(
          `${product.name} ${product.category} ${product.badge}`
        ).includes(normalizedSearch);

      const matchesCategory =
        selectedCategory === "Toate" ||
        product.category === selectedCategory;

      return matchesSearch && matchesCategory;
    });

    return [...result].sort((firstProduct, secondProduct) => {
      if (sortOption === "pret-crescator") {
        return (
          getNumericPrice(firstProduct.price) -
          getNumericPrice(secondProduct.price)
        );
      }

      if (sortOption === "pret-descrescator") {
        return (
          getNumericPrice(secondProduct.price) -
          getNumericPrice(firstProduct.price)
        );
      }

      if (sortOption === "nume-az") {
        return firstProduct.name.localeCompare(
          secondProduct.name,
          "ro"
        );
      }

      if (sortOption === "nume-za") {
        return secondProduct.name.localeCompare(
          firstProduct.name,
          "ro"
        );
      }

      return firstProduct.id - secondProduct.id;
    });
  }, [searchQuery, selectedCategory, sortOption]);

  function resetFilters() {
    setSelectedCategory("Toate");
    setSortOption("recomandate");
  }

  return (
    <section
      id="produse"
      className="bg-neutral-950 px-6 py-20 text-white"
    >
      <div className="mx-auto max-w-7xl">
        <div className="mb-10 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm uppercase tracking-[0.35em] text-[#D4AF37]">
              Selecția VIRELLO
            </p>

            <h2 className="mt-4 text-4xl font-bold sm:text-5xl">
              {searchQuery
                ? `Rezultate pentru „${searchQuery}”`
                : "Produse recomandate"}
            </h2>

            <p className="mt-4 max-w-2xl text-neutral-400">
              {filteredProducts.length}{" "}
              {filteredProducts.length === 1
                ? "produs disponibil"
                : "produse disponibile"}
            </p>
          </div>

          {searchQuery ? (
            <Link
              href="/Produse"
              className="w-fit rounded-xl border border-[#D4AF37] px-6 py-3 font-semibold text-[#D4AF37] transition hover:bg-[#D4AF37] hover:text-black"
            >
              Șterge căutarea
            </Link>
          ) : (
            <button
              type="button"
              onClick={resetFilters}
              className="w-fit rounded-xl border border-[#D4AF37] px-6 py-3 font-semibold text-[#D4AF37] transition hover:bg-[#D4AF37] hover:text-black"
            >
              Resetează filtrele
            </button>
          )}
        </div>

        <div className="mb-10 rounded-3xl border border-white/10 bg-black p-5">
          <div className="grid gap-5 lg:grid-cols-[1fr_260px]">
            <div>
              <p className="mb-3 text-sm font-semibold text-neutral-300">
                Filtrează după categorie
              </p>

              <div className="flex flex-wrap gap-2">
                {categories.map((category) => (
                  <button
                    key={category}
                    type="button"
                    onClick={() => setSelectedCategory(category)}
                    className={`rounded-xl border px-4 py-2 text-sm font-semibold transition ${
                      selectedCategory === category
                        ? "border-[#D4AF37] bg-[#D4AF37] text-black"
                        : "border-white/10 bg-white/5 text-white hover:border-[#D4AF37] hover:text-[#D4AF37]"
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label
                htmlFor="sortare-produse"
                className="mb-3 block text-sm font-semibold text-neutral-300"
              >
                Sortează produsele
              </label>

              <select
                id="sortare-produse"
                value={sortOption}
                onChange={(event) =>
                  setSortOption(event.target.value)
                }
                className="w-full rounded-xl border border-white/10 bg-neutral-900 px-4 py-3 text-white outline-none transition focus:border-[#D4AF37]"
              >
                <option value="recomandate">
                  Produse recomandate
                </option>

                <option value="pret-crescator">
                  Preț: mic spre mare
                </option>

                <option value="pret-descrescator">
                  Preț: mare spre mic
                </option>

                <option value="nume-az">
                  Nume: A–Z
                </option>

                <option value="nume-za">
                  Nume: Z–A
                </option>
              </select>
            </div>
          </div>
        </div>

        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {filteredProducts.map((product) => (
              <article
                key={product.id}
                className="group overflow-hidden rounded-3xl border border-white/10 bg-black transition duration-300 hover:-translate-y-1 hover:border-[#D4AF37]/70"
              >
                <div className="relative flex h-64 items-center justify-center bg-gradient-to-br from-neutral-800 to-neutral-950">
                  <span className="absolute left-4 top-4 z-10 rounded-full bg-[#D4AF37] px-3 py-1 text-xs font-bold text-black">
                    {product.badge}
                  </span>

                  <FavoriteButton product={product} />

                  <Link
                    href={`/produs/${product.slug}`}
                    className="flex h-full w-full items-center justify-center"
                  >
                    <div className="text-center text-neutral-600">
                      <div className="text-6xl">◇</div>

                      <p className="mt-3 text-sm">
                        Imagine produs
                      </p>
                    </div>
                  </Link>
                </div>

                <div className="p-5">
                  <p className="text-sm text-[#D4AF37]">
                    {product.category}
                  </p>

                  <h3 className="mt-2 min-h-14 text-lg font-semibold">
                    {product.name}
                  </h3>

                  <div className="mt-4 flex flex-wrap items-center gap-3">
                    <span className="text-xl font-bold">
                      {product.price}
                    </span>

                    <span className="text-sm text-neutral-500 line-through">
                      {product.oldPrice}
                    </span>
                  </div>

                  <Link
                    href={`/produs/${product.slug}`}
                    className="mt-5 block w-full rounded-xl bg-white px-4 py-3 text-center font-semibold text-black transition group-hover:bg-[#D4AF37]"
                  >
                    Vezi produsul
                  </Link>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="rounded-3xl border border-white/10 bg-black px-6 py-16 text-center">
            <div className="text-6xl">🔍</div>

            <h3 className="mt-6 text-2xl font-bold">
              Nu am găsit produse
            </h3>

            <p className="mx-auto mt-3 max-w-xl text-neutral-400">
              Nu există produse care să corespundă căutării sau
              categoriei selectate.
            </p>

            <button
              type="button"
              onClick={resetFilters}
              className="mt-8 rounded-xl bg-[#D4AF37] px-6 py-3 font-bold text-black transition hover:opacity-90"
            >
              Resetează filtrele
            </button>
          </div>
        )}
      </div>
    </section>
  );
}