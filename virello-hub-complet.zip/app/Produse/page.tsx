import Products from "../components/Products";
import Header from "../components/Header";

export default function ProdusePage() {
  return (
    <main className="min-h-screen bg-black text-white">
      <Header />

      <section className="mx-auto max-w-7xl px-6 pt-16">
        <p className="text-sm uppercase tracking-[0.35em] text-[#c9a96a]">
          Magazin
        </p>

        <h1 className="mt-4 text-4xl font-bold sm:text-6xl">
          Toate produsele
        </h1>

        <p className="mt-5 max-w-2xl text-neutral-400">
          Descoperă selecția Virello și găsește produsele potrivite pentru tine.
        </p>
      </section>

      <Products />
    </main>
  );
}